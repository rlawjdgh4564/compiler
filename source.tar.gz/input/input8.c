int main ()
{
	int a;
	int b;
	a = (1 + 2) * 3 / (1 != 2);
	b = 1 == 2 * 3 < 4 + a / 2;

	return 0;
}
