int main ()
{
	int a[10];

	a[0] = i;
	a[1] = a[0] + 1;
}
